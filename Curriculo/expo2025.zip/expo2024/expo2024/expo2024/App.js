import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';

export default function App() {
  return (
    <View style={styles.container}>
      <View style={styles.container}>
       <StatusBar style="auto" />
    </View>
        <Text>GUILHERME E.L. SILVA</Text>
        <View style={styles.tarefas}>
        <Image
            style={styles.tinyLogo}
            source={require('./src/img/monster...raisulaivieu.jpg')}
          />
        <Text style={styles.text}>
        Profissão: Programador de Jogos
        <br/>
        Idade: 45 anos
        <br/>
        Telefone: (11) 4002-8922
        <br/>
        Endereço: Xique-Xique Bahia, 001
        </Text>
      </View>
      <br/>
 
      <Text>EXPERIÊNCIAS</Text>
      <View  style={styles.tarefas}>
        <Text style={styles.text}>
              2007 | Fez uma copia de Tetris
            <br/>
              2010 | Fez sua primeira fan-Game de sonic.EXE
            <br/>
              2015 | Trabalhou por kojima
            <br/>
              2020 | Fez seu primeiro jogo independente
          </Text>
      </View>
 
      <br/>
<Text>FORMAÇÔES</Text>
<View style={styles.tarefas}>
<Text style={styles.text}>
    faculdade de Letras -  2008
<br/>
    curso de programaçao em um lugar minimamente suspeito - 2009
</Text>
</View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
